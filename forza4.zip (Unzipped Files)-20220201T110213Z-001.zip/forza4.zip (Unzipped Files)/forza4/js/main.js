"use strict"
var N
var fine=1
var turn=1
var moves = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
var cellsID = ["1", "2", "3", "4", "5", "6",
        "7", "8", "9", "10", "11", "12", 
        "13", "14", "15", "16", "17", "18", 
        "19", "20", "21", "22", "23", "24", 
        "25", "26", "27", "28", "29", "30", 
        "31", "32", "33", "34", "35", "36", 
        "37", "38", "39", "40", "41", "42"]
function giocata(Ncella){
    if (turn%2==1)
    {
        if (moves[Ncella-1]==0){
            document.getElementById(cellsID[Ncella-1]).style.backgroundColor = "black";
            turn=2;
            moves[Ncella-1]=1;
        }
        else if (moves[Ncella+6]==0){
            document.getElementById(cellsID[Ncella+6]).style.backgroundColor = "black";
            turn=2;
            moves[Ncella+6]=1;
        }
        else if (moves[Ncella+13]==0){
            document.getElementById(cellsID[Ncella+13]).style.backgroundColor = "black";
            turn=2;
            moves[Ncella+13]=1;
        }
        else if (moves[Ncella+20]==0){
            document.getElementById(cellsID[Ncella+20]).style.backgroundColor = "black";
            turn=2;
            moves[Ncella+20]=1;
        }
        else if (moves[Ncella+27]==0){
            document.getElementById(cellsID[Ncella+27]).style.backgroundColor = "black";
            turn=2;
            moves[Ncella+27]=1;
        }
        else if (moves[Ncella+34]==0){
            document.getElementById(cellsID[Ncella+34]).style.backgroundColor = "black";
            turn=2;
            moves[Ncella+34]=1;
        }
        document.getElementById('message').innerHTML = "e' il turno del giocatore " + turn;
        win(1);
    }  
    else if (turn%2==0)
    {
        if (moves[Ncella-1]==0){
            document.getElementById(cellsID[Ncella-1]).style.backgroundColor = "yellow";
            turn=1;
            moves[Ncella-1]=5;
        }
        else if (moves[Ncella+6]==0){
            document.getElementById(cellsID[Ncella+6]).style.backgroundColor = "yellow";
            turn=1;
            moves[Ncella+6]=5;
        }
        else if (moves[Ncella+13]==0){
            document.getElementById(cellsID[Ncella+13]).style.backgroundColor = "yellow";
            turn=1;
            moves[Ncella+13]=5;
        }
        else if (moves[Ncella+20]==0){
            document.getElementById(cellsID[Ncella+20]).style.backgroundColor = "yellow";
            turn=1;
            moves[Ncella+20]=5;
        }
        else if (moves[Ncella+27]==0){
            document.getElementById(cellsID[Ncella+27]).style.backgroundColor = "yellow";
            turn=1;
            moves[Ncella+27]=5;
        }
        else if (moves[Ncella+34]==0){
            document.getElementById(cellsID[Ncella+34]).style.backgroundColor = "yellow";
            turn=1;
            moves[Ncella+34]=5;
        }
        document.getElementById('message').innerHTML = "e' il turno del giocatore " + turn;
        win(2);
    }  
    
}


    function win(T){

        for(N=0; N<42; N++)
        {
            if(moves[N]+moves[N+1]+moves[N+2]+moves[N+3]==4||moves[N]+moves[N+1]+moves[N+2]+moves[N+3]==20){
                document.getElementById('message').innerHTML = "ha vinto il giocatore " + T; 
                fine=0;
            }
            else if(moves[N]+moves[N+8]+moves[N+16]+moves[N+24]==4||moves[N]+moves[N+8]+moves[N+16]+moves[N+24]==20){
                document.getElementById('message').innerHTML = "ha vinto il giocatore " + T; 
                fine=0;
            }
            else if(moves[N]+moves[N+7]+moves[N+14]+moves[N+21]==4||moves[N]+moves[N+7]+moves[N+14]+moves[N+21]==20){
                document.getElementById('message').innerHTML = "ha vinto il giocatore " + T; 
                fine=0;
            }




        }





    }
function Turno(Ncella){
    if (fine!=0){
        giocata(Ncella);
    }
        

    
}